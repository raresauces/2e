#ifndef RENDER_HPP
#define RENDER_HPP

void render(int step);
void showWave(int num);
void shake(void);

#endif // RENDER_HPP

