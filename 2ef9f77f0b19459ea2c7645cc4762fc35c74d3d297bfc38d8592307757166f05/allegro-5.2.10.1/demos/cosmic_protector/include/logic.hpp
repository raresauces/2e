#ifndef LOGIC_HPP
#define LOGIC_HPP

bool logic(int step);

extern std::list<Entity *> entities;
extern std::list<Entity *> new_entities;
extern long lastUFO;
extern bool canUFO;

#endif // LOGIC_HPP
