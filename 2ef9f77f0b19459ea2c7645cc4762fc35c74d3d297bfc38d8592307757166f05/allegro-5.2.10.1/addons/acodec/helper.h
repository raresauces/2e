#ifndef __al_included_acodec_helper_h
#define __al_included_acodec_helper_h

void _al_acodec_start_feed_thread(ALLEGRO_AUDIO_STREAM *stream);
void _al_acodec_stop_feed_thread(ALLEGRO_AUDIO_STREAM *stream);

#endif
